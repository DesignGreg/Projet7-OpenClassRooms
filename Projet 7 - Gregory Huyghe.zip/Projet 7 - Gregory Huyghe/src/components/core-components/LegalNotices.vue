<template>
  <div class="legal">
    
  </div>
</template>


<script>

</script>


<style scoped>
  
</style>